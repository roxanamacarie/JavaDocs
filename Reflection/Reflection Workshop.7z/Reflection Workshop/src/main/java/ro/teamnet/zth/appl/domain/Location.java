package ro.teamnet.zth.appl.domain;

import ro.teamnet.zth.api.annotations.Column;
import ro.teamnet.zth.api.annotations.Id;
import ro.teamnet.zth.api.annotations.Table;

/**
 * Entitate pe care o vom folosi in dezvoltarea aplicatiei,
 * si pe care o mapam cu tabela locations din baza de date.
 * Fiecarui camp din aceasta entitate ii corespunde o coloana
 * din tabela locations
 */
@Table(name = "locations")
public class Location {

    @Id(name = "location_id")
    private Integer id;

    @Column(name = "street_address")
    private String streetAddress;

    @Column(name = "postal_code")
    private String postalCode;

    @Column(name = "city")
    private String city;

    @Column(name = "state_province")
    private String stateProvince;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Location location = (Location) o;

        if (!city.equals(location.city)) return false;
        if (!id.equals(location.id)) return false;
        if (!postalCode.equals(location.postalCode)) return false;
        if (!stateProvince.equals(location.stateProvince)) return false;
        if (!streetAddress.equals(location.streetAddress)) return false;

        return true;
    }


}
