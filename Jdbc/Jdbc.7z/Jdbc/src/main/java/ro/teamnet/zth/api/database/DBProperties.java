package ro.teamnet.zth.api.database;

/**
 * Created by user on 7/8/2016.
 */
public interface DBProperties {
    String IP="192.168.99.100";
    String PORT="49161";
    String USER="AlexChirita";
    String PASS="AlexChirita";
    String DRIVER_CLASS="oracle.jdbc.driver.OracleDriver";
}
